// Copyright 2014 PDFium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "cmaps_cns1.h"

const FX_WORD g_FXCMAP_ETenms_B5_H_0[1 * 3] = {
    0x0020, 0x007E, 0x0001,
};
